# Programa que demana l'edat i diu si ets major d'edat.

edat=int(input("Quina edat tens?"))
if edat>=18:
    print("Ets major d'edat")
    print("Programa fnalitzat")
else:
    print("Ets menor d'edat")
    print("Finalitzat")