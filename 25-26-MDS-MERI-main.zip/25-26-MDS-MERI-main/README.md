# 25-26-MDS-MERI
Repositori tasques MDS curs 25 26
Exercicis senzills de python amb Jupyterlab
Què és Binder?

Binder és un servei online que permet executar notebooks Jupyter directament des del navegador.

Funciona amb repositoris de GitHub, GitLab o Zenodo.

No cal instal·lar Python, Jupyter ni cap llibreria al teu ordinador.

Podreu obrir notebooks i executar codi immediatament.

🔹 Com utilitzar Binder amb Python

Pas 1: Obre Binder

Ves a https://mybinder.org

Introdueix l’URL del teu repositori a GitHub repository name.

Deixa la branca per defecte (main) o especifica-ne una altra.

Prem Launch.

Binder crearà un entorn temporal amb Python i les llibreries del teu notebook.

Quan s’obri, veuràs el teu notebook com si estiguessis treballant a Jupyter local.

Pas 2: Programar

Pots escriure i executar codi Python en celdes (Shift + Enter).

Els canvis temporalment es guarden a l’entorn de Binder, però no al repositori.

Per guardar els canvis de manera permanent:

Descarrega el notebook: File → Download → Download .ipynb

Pujar-lo de nou al repositori GitHub.
